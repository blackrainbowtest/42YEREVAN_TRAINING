

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int    picoshell(char **cmds[])
{
	int i = 0;
	int fd[2];
	pid_t pid;
	int status;
	int exit_code = 0;
	int prev_fd = -1;

	
	while(cmds[i])
	{
		if (cmds[i + 1] && pipe(fd) == -1)
			return 1;
		pid = fork();
		if (pid == -1)
		{
			if (cmds[i + 1])
			{
				close(fd[0]);
				close(fd[1]);
				return 1;
			}
		}
		if (pid == 0)
		{
			if (prev_fd != -1)
			{
				if (dup2(prev_fd, 0) == -1)
					exit (1);
				close(prev_fd);
			}
			if (cmds[i + 1])
			{
				close(fd[0]);
				if (dup2(fd[1], 1) == -1)
					exit (1);
				close(fd[1]);
			}
			execvp(cmds[i][0], cmds[i]);
			exit (1);
		}
		if (prev_fd != -1)
			close(prev_fd);
		if (cmds[i + 1])
		{
			close(fd[1]);
			prev_fd = fd[0];
		}
		i++;
	}
	while(wait(&status) != -1)
	{
		if (WIFEXITED(status) && WEXITSTATUS(status) != 0)
			exit_code = 1;
	}
	return (exit_code);
	
}

char *ft_strdup(char *str)
{
	int i = 0;
	char *new;

	while (str[i])
		i++;
	new = malloc(i);
	i = 0;
	while(str[i])
	{
		new[i] = str[i];
		i++;
	}
	new[i] = '\0';
	return new;
}

int main(int argc, char **argv)
{
	char ***cmds;
	int i = 0;
	int count = 0;

	while(argv[i])
	{
		if (argv[i][0] != '|')
			count++;
		i++;
	}
	cmds = malloc(sizeof(char **) * (count));
	i = 0;
	cmds[0] = malloc(sizeof(char *) * 2);
	cmds[0][0] = ft_strdup(argv[1]);
	cmds[0][1] = NULL;
	cmds[1] = malloc(sizeof(char *) * 2);
	cmds[1][0] = ft_strdup(argv[3]);
	cmds[1][2] = NULL;
	cmds[2] = NULL;
	printf("pico = %d\n", picoshell(cmds));
}